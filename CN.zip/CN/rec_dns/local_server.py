import socket

s = socket.socket()
s.bind(('localhost', 12100))
s.listen(5)

print('Local DNS Server waiting...')

while True:
    c, addr = s.accept()
    domain = c.recv(1024).decode()

    r = socket.socket()
    r.connect(('localhost', 12101))
    r.send(domain.encode())

    ip = r.recv(1024).decode()
    r.close()

    c.send(ip.encode())
    c.close()