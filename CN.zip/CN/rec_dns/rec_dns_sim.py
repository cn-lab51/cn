"""SimPy model of roadside units using a shared recursive DNS resolver.

Run with ``python rec_dns_sim.py --help`` to see the configurable workload,
resolver capacity, cache TTL, and delay settings.
"""

import argparse
import ipaddress
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import simpy


DEFAULT_DNS_RECORDS = {
    "google.com": "142.250.183.14",
    "yahoo.com": "74.6.143.25",
}
DEFAULT_REQUESTS = [
    ("google.com", 0.0),
    ("yahoo.com", 0.0),
    ("unknown.com", 0.0),
    ("google.com", 0.0),
]


@dataclass
class SimulationConfig:
    resolver_capacity: int = 1
    resolver_delay: float = 0.0
    root_delay: float = 1.0
    tld_delay: float = 1.0
    authoritative_delay: float = 1.0
    transmission_delay: float = 0.0
    bandwidth_mbps: float = 10.0
    propagation_delay_ms: float = 5.0
    ttl: float = 60.0


def message_delay(payload_bytes: int, config: SimulationConfig) -> float:
    """One-way link time = serialization + propagation + optional extra delay."""
    return (
        payload_bytes * 8 / (config.bandwidth_mbps * 1_000_000)
        + config.propagation_delay_ms / 1000
        + config.transmission_delay
    )


def valid_ipv4(value: str) -> bool:
    """Return whether value is a syntactically valid IPv4 address."""
    try:
        ipaddress.IPv4Address(value)
        return True
    except (ipaddress.AddressValueError, ValueError):
        return False


def parse_dns_record(value: str) -> Tuple[str, str]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("DNS records must use domain=address")
    domain, address = value.split("=", 1)
    domain = domain.strip().lower().rstrip(".")
    address = address.strip()
    if not domain or not address:
        raise argparse.ArgumentTypeError(
            "DNS record requires a domain and a non-empty address"
        )
    return domain, address


def parse_request(value: str) -> Tuple[str, float]:
    """Parse DOMAIN or DOMAIN@ARRIVAL_TIME (simulation-time seconds)."""
    domain, separator, arrival = value.rpartition("@")
    if not separator:
        domain, arrival = value, "0"
    try:
        arrival_time = float(arrival)
    except ValueError as error:
        raise argparse.ArgumentTypeError(
            "requests must use DOMAIN or DOMAIN@ARRIVAL_TIME"
        ) from error
    domain = domain.strip().lower().rstrip(".")
    if not domain or arrival_time < 0:
        raise argparse.ArgumentTypeError(
            "request domain must be non-empty and arrival time non-negative"
        )
    return domain, arrival_time


def resolve_authoritative(env: simpy.Environment, domain: str,
                          records: Dict[str, str], config: SimulationConfig,
                          contacted: List[str]):
    contacted.append("authoritative")
    print(f"  {env.now:.3f}s authoritative query: {domain}")
    yield env.timeout(message_delay(len(domain), config))
    yield env.timeout(config.authoritative_delay)
    address = records.get(domain)
    yield env.timeout(message_delay(len(address or "NXDOMAIN"), config))
    return address


def resolve_tld(env: simpy.Environment, domain: str,
                records: Dict[str, str], config: SimulationConfig,
                contacted: List[str]):
    contacted.append("tld")
    print(f"  {env.now:.3f}s TLD query: {domain}")
    yield env.timeout(message_delay(len(domain), config))
    yield env.timeout(config.tld_delay)
    yield env.timeout(message_delay(len("authoritative referral"), config))
    return (yield env.process(
        resolve_authoritative(env, domain, records, config, contacted)
    ))


def resolve_root(env: simpy.Environment, domain: str,
                 records: Dict[str, str], config: SimulationConfig,
                 contacted: List[str]):
    contacted.append("root")
    print(f"  {env.now:.3f}s root query: {domain}")
    yield env.timeout(message_delay(len(domain), config))
    yield env.timeout(config.root_delay)
    yield env.timeout(message_delay(len("TLD referral"), config))
    return (yield env.process(
        resolve_tld(env, domain, records, config, contacted)
    ))


def resolver_query(env: simpy.Environment, unit: str, domain: str,
                   resolver: simpy.Resource, cache: Dict[str, Tuple[str, float]],
                   records: Dict[str, str], config: SimulationConfig,
                   result: Dict[str, object]):
    print(f"{env.now:.3f}s {unit} requests {domain}")
    yield env.timeout(message_delay(len(domain), config))
    resolver_arrival = env.now
    with resolver.request() as slot:
        yield slot
        yield env.timeout(config.resolver_delay)

        cached = cache.get(domain)
        if cached is not None and cached[1] > env.now:
            address = cached[0]
            result["cache_status"] = "HIT"
            result["servers_contacted"] = ["recursive_resolver"]
            print(f"  {env.now:.3f}s cache hit: {domain} -> {address}")
        else:
            if cached is not None:
                del cache[domain]
            result["servers_contacted"] = ["recursive_resolver"]
            address = yield env.process(
                resolve_root(env, domain, records, config,
                             result["servers_contacted"])
            )
            if address is None:
                result["response_status"] = "NXDOMAIN"
            elif not valid_ipv4(address):
                result["response_status"] = "INVALID_IP"
                address = None
            else:
                result["response_status"] = "SUCCESS"
                cache[domain] = (address, env.now + config.ttl)

        if result["cache_status"] == "HIT":
            result["response_status"] = "SUCCESS" if valid_ipv4(address) else "INVALID_IP"
            if result["response_status"] != "SUCCESS":
                address = None

        resolution_end = env.now

    yield env.timeout(message_delay(len(address or "Not Found"), config))
    result["ip_address"] = address
    result["resolution_time"] = resolution_end - resolver_arrival
    result["turnaround_time"] = env.now - float(result["arrival_time"])
    if result["response_status"] == "PENDING":
        result["response_status"] = "NXDOMAIN"
    print(
        f"  {env.now:.3f}s response={result['response_status']} "
        f"ip={address or '-'} resolution={result['resolution_time']:.3f}s "
        f"turnaround={result['turnaround_time']:.3f}s "
        f"cache={result['cache_status']}"
    )


def run_simulation(requests: Sequence[Tuple[str, float]],
                   records: Dict[str, str], config: SimulationConfig
                   ) -> List[Dict[str, object]]:
    env = simpy.Environment()
    resolver = simpy.Resource(env, capacity=config.resolver_capacity)
    cache: Dict[str, Tuple[str, float]] = {}
    results: List[Dict[str, object]] = []

    for index, (domain, arrival_time) in enumerate(requests, start=1):
        result: Dict[str, object] = {}
        results.append(result)
        env.process(_arrive_and_query(
            env, arrival_time, f"RSU-{index}", domain, resolver, cache,
            records, config, result
        ))

    env.run()
    print_results(results, config)
    return results


def _arrive_and_query(env: simpy.Environment, arrival_time: float,
                      unit: str, domain: str, resolver: simpy.Resource,
                      cache: Dict[str, Tuple[str, float]],
                      records: Dict[str, str], config: SimulationConfig,
                      result: Dict[str, object]):
    yield env.timeout(max(0.0, arrival_time - env.now))
    result.update({
        "arrival_time": env.now,
        "domain": domain,
        "roadside_unit": unit,
        "servers_contacted": [],
        "cache_status": "MISS",
        "response_status": "PENDING",
    })
    yield env.process(resolver_query(
        env, unit, domain, resolver, cache, records, config, result
    ))


def print_results(results: Sequence[Dict[str, object]],
                  config: SimulationConfig) -> None:
    print("\n--- DNS query records ---")
    for item in results:
        servers = ",".join(item["servers_contacted"])
        print(
            f"{item['roadside_unit']} {item['domain']}: "
            f"arrival={item['arrival_time']:.3f}s "
            f"cache={item['cache_status']} servers={servers} "
            f"resolution={item['resolution_time']:.3f}s "
            f"turnaround={item['turnaround_time']:.3f}s "
            f"status={item['response_status']} ip={item['ip_address'] or '-'}"
        )

    count = len(results)
    hits = sum(item["cache_status"] == "HIT" for item in results)
    successes = sum(item["response_status"] == "SUCCESS" for item in results)
    total_time = sum(float(item["resolution_time"]) for item in results)
    average_time = total_time / count if count else 0.0
    average_turnaround = (
        sum(float(item["turnaround_time"]) for item in results) / count
        if count else 0.0
    )
    hit_rate = hits / count * 100 if count else 0.0
    print("\n--- Analysis ---")
    print(f"Requests: {count}; resolver capacity: {config.resolver_capacity}")
    print(f"Cache hits: {hits}; cache misses: {count - hits}; hit rate: {hit_rate:.1f}%")
    print(f"Successful responses: {successes}; failed responses: {count - successes}")
    print(f"Average resolution time: {average_time:.3f}s")
    print(f"Average turnaround time: {average_turnaround:.3f}s")
    print(f"Configured cache TTL: {config.ttl:g}s")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--request", action="append", type=parse_request,
        help="request as DOMAIN or DOMAIN@ARRIVAL_SECONDS; repeatable",
    )
    parser.add_argument(
        "--dns-record", action="append", type=parse_dns_record,
        help="authoritative record as DOMAIN=IPv4; repeatable (replaces defaults)",
    )
    parser.add_argument("--resolver-capacity", type=int, default=1)
    parser.add_argument("--resolver-delay", type=float, default=0.0,
                        help="resolver processing time per query, in seconds")
    parser.add_argument("--root-delay", type=float, default=1.0)
    parser.add_argument("--tld-delay", type=float, default=1.0)
    parser.add_argument("--authoritative-delay", type=float, default=1.0)
    parser.add_argument("--transmission-delay", type=float, default=0.0,
                        help="optional extra per-message delay, in seconds")
    parser.add_argument("--bandwidth-mbps", type=float, default=10.0)
    parser.add_argument("--propagation-delay-ms", type=float, default=5.0)
    parser.add_argument("--ttl", type=float, default=60.0,
                        help="positive cache lifetime for valid answers, in seconds")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.resolver_capacity < 1:
        parser.error("--resolver-capacity must be at least 1")
    for name in ("resolver_delay", "root_delay", "tld_delay",
                 "authoritative_delay", "transmission_delay"):
        if getattr(args, name) < 0:
            parser.error(f"--{name.replace('_', '-')} cannot be negative")
    if args.ttl <= 0:
        parser.error("--ttl must be greater than zero")
    if args.bandwidth_mbps <= 0 or args.propagation_delay_ms < 0:
        parser.error("bandwidth must be positive and propagation delay non-negative")

    config = SimulationConfig(
        resolver_capacity=args.resolver_capacity,
        resolver_delay=args.resolver_delay,
        root_delay=args.root_delay,
        tld_delay=args.tld_delay,
        authoritative_delay=args.authoritative_delay,
        transmission_delay=args.transmission_delay,
        bandwidth_mbps=args.bandwidth_mbps,
        propagation_delay_ms=args.propagation_delay_ms,
        ttl=args.ttl,
    )
    records = dict(args.dns_record) if args.dns_record else dict(DEFAULT_DNS_RECORDS)
    requests = args.request if args.request is not None else DEFAULT_REQUESTS
    run_simulation(requests, records, config)


if __name__ == "__main__":
    main()
