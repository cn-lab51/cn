import socket

s = socket.socket()
s.bind(('localhost', 12102))
s.listen(5)

print('TLD Server waiting...')

while True:
    c, addr = s.accept()
    domain = c.recv(1024).decode()

    r = socket.socket()
    r.connect(('localhost', 12103))
    r.send(domain.encode())

    result = r.recv(1024).decode()
    r.close()

    c.send(result.encode())
    c.close()