from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

def read_mail(env, stats, n, timing):
    start = env.now
    print(f"{env.now:.1f}s Client {n}: LOGIN and SELECT INBOX")
    request_size = len("LOGIN SELECT INBOX")
    yield env.timeout(timing.one_way_delay(request_size))
    yield env.timeout(timing.processing_delay)
    print(f"{env.now:.1f}s Client {n}: FETCH message")
    yield env.timeout(timing.one_way_delay(timing.packet_size_bytes))
    yield env.timeout(timing.processing_delay)
    yield env.timeout(timing.one_way_delay(len("FETCH response")))
    print(f"{env.now:.1f}s Client {n}: message read; LOGOUT")
    stats["ok"] += 1; stats["delay"] += env.now-start

env = simpy.Environment(); timing = get_link_timing(); stats = {"ok": 0, "delay": 0.0}
for n in range(1, 4): env.process(read_mail(env, stats, n, timing))
env.run()
print("Completed sessions:", stats["ok"], "Average session time:", round(stats["delay"]/stats["ok"], 2), "s")
