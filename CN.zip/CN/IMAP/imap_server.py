import socket

HOST, PORT = "127.0.0.1", 1143  # demo port; IMAP commonly uses 143
MAILS = ["Subject: Welcome\n\nFirst demo message", "Subject: Lab\n\nSecond demo message"]
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT)); s.listen(1)
    print(f"IMAP demo server listening on {HOST}:{PORT}")
    conn, addr = s.accept()
    with conn:
        f = conn.makefile("rwb")
        f.write(b"* OK IMAP demo ready\r\n"); f.flush()
        while True:
            line = f.readline().decode(errors="replace").strip()
            if not line: break
            parts = line.split(maxsplit=2)
            tag = parts[0] if parts else "A"
            cmd = parts[1].upper() if len(parts) > 1 else ""
            if cmd == "LOGIN":
                out = f"{tag} OK login successful\r\n"
            elif cmd == "SELECT":
                out = f"* {len(MAILS)} EXISTS\r\n{tag} OK mailbox selected\r\n"
            elif cmd == "FETCH":
                try:
                    i = int(parts[2].split()[0]) - 1
                    out = f"* {i+1} FETCH (BODY[{len(MAILS[i])}])\r\n{MAILS[i]}\r\n{tag} OK FETCH completed\r\n"
                except Exception:
                    out = f"{tag} NO invalid message number\r\n"
            elif cmd == "LOGOUT":
                f.write(b"* BYE logging out\r\n"); f.write(f"{tag} OK logout\r\n".encode()); f.flush(); break
            else:
                out = f"{tag} OK command accepted (demo)\r\n"
            f.write(out.encode()); f.flush()
