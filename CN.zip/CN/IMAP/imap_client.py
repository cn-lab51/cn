import socket

HOST, PORT = "127.0.0.1", 1143
with socket.create_connection((HOST, PORT)) as s:
    f = s.makefile("rwb")
    print(f.readline().decode().strip())
    for cmd in ["A1 LOGIN student demo", "A2 SELECT INBOX", "A3 FETCH 1 BODY[]", "A4 LOGOUT"]:
        print(">", cmd)
        f.write((cmd + "\r\n").encode()); f.flush()
        # Read one or more response lines until the tagged completion line.
        while True:
            line = f.readline().decode(errors="replace")
            if not line: break
            print(line.rstrip())
            if line.startswith(cmd.split()[0] + " "): break
        if "LOGOUT" in cmd: break
