import socket

s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('localhost', 1226))
s.listen(1)

print("Server waiting for client...")

c, addr = s.accept()

data = c.recv(1024).decode()

destuffed = ""
i = 0

while i < len(data):
    if data[i:i+3] == "ESC":
        i += 3
        if i < len(data):
            destuffed += data[i]
    else:
        destuffed += data[i]
    i += 1

print("Received stuffed data:", data)
print("Destuffed data:", destuffed)

c.send(destuffed.encode())

c.close()
s.close()
