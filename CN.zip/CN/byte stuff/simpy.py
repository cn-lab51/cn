from pathlib import Path
import sys

script_directory = Path(__file__).resolve().parent
project_directory = script_directory.parent
sys.path[:] = [
    entry for entry in sys.path
    if Path(entry or ".").resolve() != script_directory
]
sys.path.insert(0, str(project_directory))

import simpy

from simpy_timing import get_link_timing, payload_size

def sender(env, channel, data, timing):
    stuffed = ""
    i = 0

    while i < len(data):
        if data[i:i+3] == "ESC" or data[i] == '$':
            stuffed += "ESC"
        stuffed += data[i]
        i += 1

    print("Sender: Original data =", data)
    print("Sender: Stuffed data  =", stuffed)

    yield env.timeout(timing.one_way_delay(payload_size(stuffed, timing.packet_size_bytes)))
    yield channel.put(stuffed)

def receiver(env, channel, timing):
    stuffed = yield channel.get()
    yield env.timeout(timing.processing_delay)

    destuffed = ""
    i = 0

    while i < len(stuffed):
        if stuffed[i:i+3] == "ESC":
            i += 3
            if i < len(stuffed):
                destuffed += stuffed[i]
        else:
            destuffed += stuffed[i]
        i += 1

    print("Receiver: Received stuffed data =", stuffed)
    print("Receiver: Destuffed data        =", destuffed)

env = simpy.Environment()
timing = get_link_timing()
channel = simpy.Store(env)

data = input("Enter data: ")

env.process(sender(env, channel, data, timing))
env.process(receiver(env, channel, timing))

env.run()
