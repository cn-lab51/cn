import socket

c = socket.socket()
c.connect(('localhost', 1226))

data = input("Enter data: ")

stuffed = ""
i = 0

while i < len(data):
    if data[i:i+3] == "ESC" or data[i] == '$':
        stuffed += "ESC"
    stuffed += data[i]
    i += 1

print("Stuffed data:", stuffed)

c.send(stuffed.encode())

result = c.recv(1024).decode()
print("Received destuffed data:", result)

c.close()
