import socket

s = socket.socket()
s.bind(('localhost', 12002))
s.listen(5)

print('TLD Server waiting...')

while True:
    c, addr = s.accept()
    domain = c.recv(1024).decode()

    print('TLD received:', domain)
    c.send('Authoritative server referral'.encode())
    c.close()