"""Iterative DNS demonstration with calculated, configurable link timing."""

from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing


DNS = {
    "google.com": "142.250.183.14",
    "yahoo.com": "74.6.143.25",
}


def root(env, domain, data, timing):
    data["step"] += 1
    data["servers"].append("root")
    print(f"Time: {env.now:.3f} | Step: {data['step']} | Root server: {domain}")
    yield env.timeout(timing.one_way_delay(len(domain)))
    yield env.timeout(timing.processing_delay)
    yield env.timeout(timing.one_way_delay(len("TLD referral")))
    print("Root returns TLD referral")
    return "TLD"


def tld(env, domain, data, timing):
    data["step"] += 1
    data["servers"].append("tld")
    print(f"Time: {env.now:.3f} | Step: {data['step']} | TLD server: {domain}")
    yield env.timeout(timing.one_way_delay(len(domain)))
    yield env.timeout(timing.processing_delay)
    yield env.timeout(timing.one_way_delay(len("AUTH referral")))
    print("TLD returns Authoritative referral")
    return "AUTH"


def auth(env, domain, data, timing):
    data["step"] += 1
    data["servers"].append("authoritative")
    print(f"Time: {env.now:.3f} | Step: {data['step']} | Authoritative server: {domain}")
    yield env.timeout(timing.one_way_delay(len(domain)))
    yield env.timeout(timing.processing_delay)
    address = DNS.get(domain, "Not Found")
    yield env.timeout(timing.one_way_delay(len(address)))
    return address


def local_dns(env, domain, data, timing):
    data["step"] += 1
    data["servers"].append("local resolver")
    print(f"Time: {env.now:.3f} | Step: {data['step']} | Local DNS received: {domain}")
    yield env.timeout(timing.one_way_delay(len(domain)))
    yield env.timeout(timing.processing_delay)
    yield env.process(root(env, domain, data, timing))
    yield env.process(tld(env, domain, data, timing))
    return (yield env.process(auth(env, domain, data, timing)))


def client(env, domain, timing):
    start = env.now
    data = {"step": 0, "servers": []}
    print(f"\nClient requests: {domain}")
    address = yield env.process(local_dns(env, domain, data, timing))
    turnaround = env.now - start
    print("IP Address:", address)
    print(f"Turnaround time: {turnaround:.3f} seconds")
    print("DNS servers contacted:", ", ".join(data["servers"]))
    print("Total Steps:", data["step"])
    print("-" * 35)


def main():
    timing = get_link_timing()
    env = simpy.Environment()
    for domain in ("google.com", "yahoo.com", "unknown.com"):
        env.process(client(env, domain, timing))
    env.run()


if __name__ == "__main__":
    main()
