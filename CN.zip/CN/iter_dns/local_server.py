import socket

s = socket.socket()
s.bind(('localhost', 12000))
s.listen(5)

print('Local DNS Server waiting...')

while True:
    c, addr = s.accept()
    domain = c.recv(1024).decode()

    print('Domain received:', domain)

    # Ask Root server
    r = socket.socket()
    r.connect(('localhost', 12001))
    r.send(domain.encode())
    r.recv(1024)
    r.close()

    # Ask TLD server
    r = socket.socket()
    r.connect(('localhost', 12002))
    r.send(domain.encode())
    r.recv(1024)
    r.close()

    # Ask Authoritative server
    r = socket.socket()
    r.connect(('localhost', 12003))
    r.send(domain.encode())
    ip = r.recv(1024).decode()
    r.close()

    c.send(ip.encode())
    c.close()