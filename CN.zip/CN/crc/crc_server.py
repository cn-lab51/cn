import socket
import threading


def crc_check(data, generator):
    data = list(data)
    generator = list(generator)

    
    for i in range(len(data) - len(generator) + 1):

        if data[i] == '1':

            for j in range(len(generator)):
                data[i + j] = str(
                    int(data[i + j]) ^ int(generator[j])
                )

    return ''.join(data[-(len(generator) - 1):])


def client_handler(client, address):
    print("Client connected:", address)

    try:
        stream = client.makefile("rwb")
        frame = stream.readline().decode().strip()
        generator = stream.readline().decode().strip()
        if not frame or not generator:
            return

        print("Received Frame:", frame)
        print("Generator:", generator)

        
        if not all(bit in "01" for bit in frame):
            stream.write(b"Invalid Frame\n"); stream.flush()
            return

        if not all(bit in "01" for bit in generator):
            stream.write(b"Invalid Generator\n"); stream.flush()
            return

        if len(generator) < 2:
            stream.write(b"Invalid Generator\n"); stream.flush()
            return

        
        remainder = crc_check(frame, generator)

        print("CRC Remainder:", remainder)

        
        if remainder == "0" * (len(generator) - 1):
            response = "Frame Accepted - No Error"
        else:
            response = "Frame Rejected - Error Detected"

        
        stream.write((response + "\n").encode()); stream.flush()

    except Exception as e:
        print("Error:", e)

    finally:
        client.close()
        print("Client disconnected:", address)



server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind server
server.bind(("127.0.0.1", 5003))

# Listen for clients
server.listen(5)

print("CRC Server Started")
print("Server IP: 127.0.0.1")
print("Server Port: 5001")
print("Waiting for clients...")

while True:
    client, address = server.accept()

    # Create a thread for each client
    thread = threading.Thread(
        target=client_handler,
        args=(client, address)
    )

    thread.start()
