
import simpy
import re
import time
import ipaddress
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing, payload_size

# Validate IP address
def valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


# Validate MAC address
def valid_mac(mac):
    pattern = r"^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$"
    return re.fullmatch(pattern, mac) is not None


# ARP client process
def arp_client(env, request_channel, reply_channel,
               packet_channel, source_ip, source_mac,
               destination_ip, data, stats, timing):

    start_time = env.now

    # Create ARP request
    request = source_ip + "|" + source_mac + "|" + destination_ip

    print(f"Time {env.now:.2f}: ARP Request Created")
    print("Request:", request)

    # Broadcast ARP request
    yield env.timeout(timing.one_way_delay(payload_size(request, timing.packet_size_bytes)))
    yield request_channel.put(request)

    stats["requests"] += 1

    print(f"Time {env.now:.2f}: ARP Request Broadcasted")
    print(f"Time {env.now:.2f}: Waiting for ARP Reply")

    # Wait for ARP reply
    reply = yield reply_channel.get()

    print(f"Time {env.now:.2f}: ARP Reply Received")
    print("Reply:", reply)

    parts = reply.split("|")
    destination_mac = parts[3]

    print("Destination MAC:", destination_mac)

    # Construct data packet
    packet = (
        source_ip + "|" +
        source_mac + "|" +
        destination_ip + "|" +
        destination_mac + "|" +
        data
    )

    print(f"Time {env.now:.2f}: Sending Data Packet")
    print("Packet:", packet)

    yield env.timeout(timing.one_way_delay(payload_size(packet, timing.packet_size_bytes)))
    yield packet_channel.put(packet)

    stats["sent"] += 1


# ARP responder and packet receiver process
def arp_server(env, request_channel, reply_channel,
               packet_channel, destination_ip,
               destination_mac, stats, timing):

    while True:
        # Wait for ARP request
        request = yield request_channel.get()

        parts = request.split("|")
        source_ip = parts[0]
        source_mac = parts[1]
        requested_ip = parts[2]

        print(f"Time {env.now:.2f}: ARP Request Received")
        yield env.timeout(timing.processing_delay)

        # Check whether requested IP belongs to this host
        if requested_ip == destination_ip:
            reply = (
                source_ip + "|" +
                source_mac + "|" +
                destination_ip + "|" +
                destination_mac
            )

            print(f"Time {env.now:.2f}: ARP Reply Created")

            yield env.timeout(timing.one_way_delay(payload_size(reply, timing.packet_size_bytes)))
            yield reply_channel.put(reply)
            stats["replies"] += 1
            stats["resolved"] += 1

            # Receive the data packet
            packet = yield packet_channel.get()

            print(f"Time {env.now:.2f}: Data Packet Received")
            print("Received Packet:", packet)

            stats["received"] += 1

        else:
            print(f"Time {env.now:.2f}: Destination IP Not Found")
            stats["failed"] += 1


# Main program
source_ip = input("Source IP: ").strip()
source_mac = input("Source MAC: ").strip()
destination_ip = input("Destination IP: ").strip()
destination_mac = input("Destination MAC: ").strip()
data = input("Enter 16-bit data: ").strip()

# Validate input
if (
    not valid_ip(source_ip)
    or not valid_ip(destination_ip)
):
    print("Invalid IP address")

elif (
    not valid_mac(source_mac)
    or not valid_mac(destination_mac)
):
    print("Invalid MAC address")

elif (
    len(data) != 16
    or any(bit not in "01" for bit in data)
):
    print("Data must contain exactly 16 bits")

elif source_ip == destination_ip:
    print("Source and destination IP must be different")

else:
    # Initialize simulation
    env = simpy.Environment()
    timing = get_link_timing()

    request_channel = simpy.Store(env)
    reply_channel = simpy.Store(env)
    packet_channel = simpy.Store(env)

    stats = {
        "requests": 0,
        "replies": 0,
        "resolved": 0,
        "failed": 0,
        "sent": 0,
        "received": 0
    }

    # Start server process
    env.process(
        arp_server(
            env,
            request_channel,
            reply_channel,
            packet_channel,
            destination_ip,
            destination_mac,
            stats,
            timing
        )
    )

    # Start client process
    client_process = env.process(
        arp_client(
            env,
            request_channel,
            reply_channel,
            packet_channel,
            source_ip,
            source_mac,
            destination_ip,
            data,
            stats,
            timing
        )
    )

    start = time.perf_counter()

    # Run until client finishes
    env.run(until=client_process)

    execution_time = time.perf_counter() - start

    # Performance report
    print("\n====== ARP PERFORMANCE REPORT ======")
    print("ARP requests:", stats["requests"])
    print("ARP replies:", stats["replies"])
    print("Successful resolutions:", stats["resolved"])
    print("Failed resolutions:", stats["failed"])
    print("Packets sent:", stats["sent"])
    print("Packets received:", stats["received"])

    if stats["received"] > 0:
        print("Packet delivery ratio: 100.00%")
        print(f"Average resolution and delivery time: {env.now:.2f} seconds")
        print(f"Throughput: {stats['received'] / env.now:.2f} packets/second")

    print(f"Simulation time: {env.now:.2f} seconds")
    print(f"Actual execution time: {execution_time:.6f} seconds")
