import socket
import re


def valid_ip(ip):
    parts = ip.split(".")

    if len(parts) != 4:
        return False

    for part in parts:
        if not part.isdigit() or int(part) < 0 or int(part) > 255:
            return False

    return True


def valid_mac(mac):
    pattern = r"^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$"
    return re.match(pattern, mac) is not None


client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

client.bind(("0.0.0.0", 5011))

print("===== ARP CLIENT =====")

ip = input("Enter IP address: ")
mac = input("Enter MAC address: ")

# Validate IP
if not valid_ip(ip):
    print("Invalid IP address")
    exit()

# Validate MAC
if not valid_mac(mac):
    print("Invalid MAC address")
    exit()

print("\nWaiting for ARP Request...")

# Receive ARP request
data, server_address = client.recvfrom(1024)

request = data.decode()

print("ARP Request Received:")
print(request)

# Split request
parts = request.split("|")

source_ip = parts[0]
source_mac = parts[1]
destination_ip = parts[2]

# Check destination IP
if destination_ip == ip:

    print("\nIP address matches")

    # Create ARP Reply
    reply = (
        source_ip + "|" +
        source_mac + "|" +
        destination_ip + "|" +
        mac
    )

    print("ARP Reply Sent:")
    print(reply)

    # Send reply to server
    client.sendto(
        reply.encode(),
        (server_address[0], 5044)
    )

    # Receive final packet
    packet, address = client.recvfrom(1024)

    print("\nReceived Packet is:")
    print(packet.decode())

else:
    print("\nIP address does not match")

client.close()
