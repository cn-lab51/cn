import socket
import re
 

def valid_ip(ip):
    parts = ip.split(".")

    if len(parts) != 4:
        return False

    for part in parts:
        if not part.isdigit() or int(part) < 0 or int(part) > 255:
            return False

    return True
 

def valid_mac(mac):
    pattern = r"^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$"
    return re.match(pattern, mac) is not None


server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


server.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)


server.bind(("0.0.0.0", 5044))

print("===== ARP SERVER =====")


source_ip = input("Source IP: ")
source_mac = input("Source MAC: ")
destination_ip = input("Destination IP: ")
data = input("16 bit data: ")


if not valid_ip(source_ip) or not valid_ip(destination_ip):
    print("Invalid IP address")
    exit()


if not valid_mac(source_mac):
    print("Invalid MAC address")
    exit()


if len(data) != 16 or any(bit not in "01" for bit in data):
    print("Data must contain exactly 16 bits")
    exit()


request = source_ip + "|" + source_mac + "|" + destination_ip

print("\nDeveloping ARP Request packet")
print(request)


server.sendto(
    request.encode(),
    ("127.0.0.1", 5011)
)

print("\nARP Request Broadcasted")
print("Waiting for ARP Reply...")


reply, address = server.recvfrom(1024)

reply = reply.decode()

print("ARP Reply Received:")
print(reply)


parts = reply.split("|")

destination_mac = parts[3]

print("\nDestination MAC:", destination_mac)


packet = (
    source_ip + "|" +
    source_mac + "|" +
    destination_ip + "|" +
    destination_mac + "|" +
    data
)

print("\nSending Packet:")
print(packet)


server.sendto(packet.encode(), address)

print("\nPacket Sent Successfully")

server.close()
