
import simpy
import ipaddress
import time
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing, payload_size

# CLIENT PROCESS
def client(env, request_channel, response_channel, ip, stats, timing):

    start_time = env.now

    print("\nTime", env.now, ": Client started")
    print("Step 1: Client prepares IP address:", ip)

    # Step 2: Send request to server
    yield env.timeout(timing.one_way_delay(payload_size(ip, timing.packet_size_bytes)))
    yield request_channel.put(ip)

    stats["requests_sent"] += 1

    print("Time", env.now, ": Step 2 - IP address sent to server")

    # Step 3: Wait for server response
    print("Time", env.now, ": Step 3 - Waiting for server response")

    result = yield response_channel.get()

    end_time = env.now

    # Step 4: Display result
    print("\nTime", env.now, ": Step 4 - Response received")
    print("\n----- SERVER RESPONSE -----")

    for key, value in result.items():
        print(key + ":", value)

    stats["responses_received"] += 1
    stats["response_time"] = end_time - start_time


# SERVER PROCESS
def server(env, request_channel, response_channel, stats, timing):

    while True:

        # Step 1: Receive client request
        ip = yield request_channel.get()

        print("\nTime", env.now, ": Server received request")
        print("Received IP address:", ip)

        stats["requests_received"] += 1

        # Step 2: Process the request
        yield env.timeout(timing.processing_delay)

        print("Time", env.now, ": Server processing IP address")

        # Step 3: Calculate network details
        network = ipaddress.ip_network(ip + "/24", strict=False)

        network_address = network.network_address
        broadcast_address = network.broadcast_address

        first_ip = network_address + 1
        last_ip = broadcast_address - 1

        # Prepare response
        result = {
            "IP Address": ip,
            "Network Address": str(network_address),
            "Broadcast Address": str(broadcast_address),
            "First Usable IP": str(first_ip),
            "Last Usable IP": str(last_ip)
        }

        print("Time", env.now, ": Network details calculated")

        # Step 4: Send response
        yield env.timeout(timing.one_way_delay(payload_size(result, timing.packet_size_bytes)))

        yield response_channel.put(result)

        stats["responses_sent"] += 1

        print("Time", env.now, ": Server sent response to client")


# MAIN PROGRAM

# Step 1: Get IP address
ip = input("Enter IPv4 address: ").strip()

# Step 2: Validate IP address
try:
    address = ipaddress.ip_address(ip)

    if not isinstance(address, ipaddress.IPv4Address):
        raise ValueError

except ValueError:
    print("Invalid IPv4 address!")
    raise SystemExit


# Step 3: Create SimPy environment
env = simpy.Environment()
timing = get_link_timing()

# Step 4: Create communication channels
request_channel = simpy.Store(env)
response_channel = simpy.Store(env)

# Step 5: Initialize performance statistics
stats = {
    "requests_sent": 0,
    "requests_received": 0,
    "responses_sent": 0,
    "responses_received": 0,
    "response_time": 0
}

# Step 6: Start server and client
env.process(
    server(env, request_channel, response_channel, stats, timing)
)

client_process = env.process(
    client(env, request_channel, response_channel, ip, stats, timing)
)

# Step 7: Measure actual execution time
start = time.perf_counter()

# Run simulation until client finishes
env.run(until=client_process)

execution_time = time.perf_counter() - start


# PERFORMANCE REPORT
print("\n========== PERFORMANCE REPORT ==========")

print("Requests sent:", stats["requests_sent"])
print("Requests received:", stats["requests_received"])
print("Responses sent:", stats["responses_sent"])
print("Responses received:", stats["responses_received"])

if stats["requests_sent"] > 0:
    success_rate = (
        stats["responses_received"] / stats["requests_sent"]
    ) * 100

    print("Successful response rate:", round(success_rate, 2), "%")

print("Total simulation time:", env.now, "seconds")
print("Response time:", stats["response_time"], "seconds")
print("Actual execution time:", round(execution_time, 6), "seconds")

print("========================================")
