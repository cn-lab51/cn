
import socket
import ipaddress

# Create TCP socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind server to localhost and port 12345
s.bind(('localhost', 12345))

# Listen for client connection
s.listen(1)

print("Server is waiting for client...")

# Accept client connection
c, addr = s.accept()

print("Client connected:", addr)

# Receive IP address from client
ip = c.recv(1024).decode()

print("Received IP address:", ip)

try:
    # Validate IPv4 address
    address = ipaddress.ip_address(ip)

    if not isinstance(address, ipaddress.IPv4Address):
        raise ValueError

    # Calculate network using /24 subnet
    network = ipaddress.ip_network(ip + '/24', strict=False)

    # Find first and last usable IP addresses
    first_ip = network.network_address + 1
    last_ip = network.broadcast_address - 1

    # Prepare response
    result = (
        "Network Address: " + str(network.network_address) +
        "\nBroadcast Address: " + str(network.broadcast_address) +
        "\nFirst Usable IP: " + str(first_ip) +
        "\nLast Usable IP: " + str(last_ip)
    )

except ValueError:
    result = "Invalid IPv4 address!"

# Send result to client
c.send(result.encode())

print("Response sent to client")

# Close connections
c.close()
s.close()

print("Server closed")
