from pathlib import Path
import sys

import simpy
import ipaddress

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing, payload_size

def client(env, server, timing):
    ip = '192.23.2.56'

    print(f"{env.now}: Client sends IP {ip}")

    yield env.timeout(timing.one_way_delay(payload_size(ip, timing.packet_size_bytes)))

    result = server(ip)
    yield env.timeout(timing.processing_delay)

    print(f"{env.now}: {result}")


def server(ip):
    network = ipaddress.ip_network(ip + '/24', strict=False)

    first = network.network_address + 1
    last = network.broadcast_address - 1

    return f"First usable IP: {first}, Last usable IP: {last}"


env = simpy.Environment()
timing = get_link_timing()

env.process(client(env, server, timing))

env.run()
