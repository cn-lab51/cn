
import socket
import ipaddress

# Get IP address from user
ip = input("Enter IPv4 address: ").strip()

# Validate IP address
try:
    address = ipaddress.ip_address(ip)

    if not isinstance(address, ipaddress.IPv4Address):
        raise ValueError

except ValueError:
    print("Invalid IPv4 address!")
    raise SystemExit

# Create TCP socket
c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to server
c.connect(('localhost', 12345))

print("Connected to server")

# Send IP address to server
c.send(ip.encode())

print("IP address sent to server")

# Receive response
result = c.recv(1024).decode()

# Display result
print("\nServer Response:")
print(result)

# Close connection
c.close()

print("Client closed")
