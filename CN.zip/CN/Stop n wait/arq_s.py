import socket

s = socket.socket()
s.bind(('localhost', 1234))
s.listen(1)

print("Server waiting...")
c, addr = s.accept()
 
while True:
    frame = c.recv(1024).decode()

    if frame == "END" or not frame:
        break

    print("Received:", frame)
    ack = "ACK"
    c.send(ack.encode())
    print("ACK sent")

c.close()
s.close()