import socket

c = socket.socket()
c.settimeout(3)
c.connect(('localhost', 1234))

frames = ["Frame 1", "Frame 2", "Frame 3"]

for frame in frames:
    while True:
        print("Sending:", frame)
        c.send(frame.encode())

        try:
            ack = c.recv(1024).decode()

            if ack == "ACK":
                print("ACK received")
                break

        except socket.timeout:
            print("Timeout! Retransmitting...")

c.send("END".encode())
c.close()