import simpy
import random
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

def sender(env, timing):
    frames = ["Frame 1", "Frame 2", "Frame 3"]

    for frame in frames:
        while True:
            print(f"{env.now}: Sending {frame}")

            yield env.timeout(timing.one_way_delay(timing.packet_size_bytes))

            # Simulate ACK loss
            if random.random() < 0.4:
                print(f"{env.now}: ACK lost! Retransmitting...")
                yield env.timeout(timing.one_way_delay(len("ACK")))
            else:
                print(f"{env.now}: ACK received for {frame}")
                break

env = simpy.Environment()
timing = get_link_timing()
env.process(sender(env, timing))
env.run()
