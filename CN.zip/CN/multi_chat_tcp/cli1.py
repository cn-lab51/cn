import socket
import threading

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 5000))

username = input("Enter your username: ")
client.sendall((username + "\n").encode())
receiver = client.makefile("rb")

print("Connected to server.")

def receive():
    while True:
        try:
            data = receiver.readline().decode(errors="replace")

            if not data:
                break
            print("\n" + data.rstrip("\r\n"))
        except:
            break

threading.Thread(target=receive, daemon=True).start()

while True:
    message = input(username + ": ")
    client.sendall((message + "\n").encode())

    if message.lower() == "exit":
        print("Closing client...")
        break

client.close()
