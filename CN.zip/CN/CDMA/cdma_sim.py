from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

def add(a, b):
    return [x + y for x, y in zip(a, b)]

def multiply(a, b):
    return [x * y for x, y in zip(a, b)]

def client(env, name, data, code, channel, signals, timing):
    print(f"{name} sending data: {data}")
    signal = [data * x for x in code]
    signals.append(signal)

    print(f"{name} chipping sequence: {code}")
    print(f"{name} transmitted signal: {signal}")

    yield env.timeout(timing.one_way_delay(len(signal)))
    yield channel.put(signal)


def server(env, channel, code1, code2, timing):
    signal1 = yield channel.get()
    signal2 = yield channel.get()
    yield env.timeout(timing.processing_delay)

    print("\nServer received both signals")

    combined = add(signal1, signal2)
    print("Combined signal:", combined)

    result1 = sum(multiply(combined, code1)) // len(code1)
    result2 = sum(multiply(combined, code2)) // len(code2)

    print("Decoded data from Client 1:", result1)
    print("Decoded data from Client 2:", result2)


env = simpy.Environment()
timing = get_link_timing()
channel = simpy.Store(env)
signals = []

data1 = 1
data2 = -1

code1 = [1, 1, 1, 1]
code2 = [1, -1, 1, -1]

env.process(server(env, channel, code1, code2, timing))
env.process(client(env, "Client 1", data1, code1, channel, signals, timing))
env.process(client(env, "Client 2", data2, code2, channel, signals, timing))

env.run()
