import socket

def add(a, b):
    return [x + y for x, y in zip(a, b)]

def multiply(a, b):
    return [x * y for x, y in zip(a, b)]

s = socket.socket()
s.bind(('localhost', 1233))
s.listen(2)

print("Server waiting for 2 clients...")

c1, addr1 = s.accept()
print("Client 1 connected")
c2, addr2 = s.accept()
print("Client 2 connected")

data1 = c1.recv(1024).decode().split()
data2 = c2.recv(1024).decode().split()

d1 = int(data1[0])
d2 = int(data2[0])

code1 = list(map(int, data1[1:]))
code2 = list(map(int, data2[1:]))

signal1 = [d1 * x for x in code1]
signal2 = [d2 * x for x in code2]

combined = add(signal1, signal2)

print("Client 1 signal:", signal1)
print("Client 2 signal:", signal2)
print("Combined signal:", combined)

result1 = sum(multiply(combined, code1)) // len(code1)
result2 = sum(multiply(combined, code2)) // len(code2)

print("Decoded data from Client 1:", result1)
print("Decoded data from Client 2:", result2)

c1.close()
c2.close()
s.close()