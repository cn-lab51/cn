
import socket
import re

def valid_mac(mac):
    pattern = r"^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$"
    return re.fullmatch(pattern, mac) is not None

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

print("===== RARP CLIENT =====")

mac = input("Enter client MAC address: ").strip()

if not valid_mac(mac):
    print("Invalid MAC address")
    client.close()
    raise SystemExit

client.connect(("127.0.0.1", 5044))

print("\nCreating RARP Request")
print("Request:", mac)

client.sendall(mac.encode())

print("\nRARP Request Sent")
print("Waiting for RARP Reply...")

data = client.recv(1024).decode()
print("\nRARP Reply Received:")
print(data)

parts = data.split("|", 1)

if parts[0] == "SUCCESS":
    print("\nRARP SUCCESSFUL")
    print("Client MAC Address:", mac)
    print("Assigned IP Address:", parts[1])
else:
    print("\nRARP FAILED")
    print("Reason:", parts[1])

client.close()
print("\nRARP Client Closed")
