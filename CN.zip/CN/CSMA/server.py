import socket
import simpy
import random
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

random.seed(10)

N = 5
CW_MIN, CW_MAX = 4, 16
MAX_RETRIES = 4

def node(env, name, channel, stats, timing):
    while True:
        yield env.timeout(random.expovariate(timing.packet_arrival_rate_pps))
        stats["generated"] += 1
        print(f"{env.now:.3f}: {name} packet generated")

        cw, retry = CW_MIN, 0

        while retry <= MAX_RETRIES:
            backoff = random.randrange(cw)
            print(name, "Backoff:", backoff)

            while backoff > 0:
                yield env.timeout(2 * timing.propagation_delay)
                if not channel["busy"]:
                    backoff -= 1

            yield env.timeout(timing.processing_delay)

            if channel["busy"]:
                stats["collisions"] += 1
                retry += 1
                stats["retries"] += 1
                cw = min(cw * 2, CW_MAX)
                print(name, "Collision, retry:", retry)
                continue

            channel["busy"] = True
            print(name, "Transmitting")
            yield env.timeout(timing.transmission_time())
            channel["busy"] = False
            yield env.timeout(timing.propagation_delay)
            stats["success"] += 1
            print(name, "Transmission successful")
            break

        if retry > MAX_RETRIES:
            stats["dropped"] += 1
            print(name, "Packet dropped")

def run_simulation(timing):
    env = simpy.Environment()
    channel = {"busy": False}
    stats = {"generated": 0, "success": 0, "collisions": 0, "retries": 0, "dropped": 0}

    for i in range(N):
        env.process(node(env, f"N{i+1}", channel, stats, timing))

    print("CSMA/CA Simulation Started")
    env.run(until=timing.simulation_time_s)

    print("\n--- RESULTS ---")
    for key, value in stats.items():
        print(key.capitalize(), ":", value)

    print("CSMA/CA Simulation Completed")
    return stats


timing = get_link_timing()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("localhost", 1225))
s.listen(1)

print("Server waiting for client...")

c, addr = s.accept()
print("Connected to:", addr)

stats = run_simulation(timing)
c.sendall(json.dumps(stats).encode())

c.close()
s.close()
