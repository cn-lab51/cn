import socket
import json

c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
c.connect(("localhost", 1225))

data = b""

while True:
    part = c.recv(1024)
    if not part:
        break
    data += part

stats = json.loads(data.decode())

print("\n--- CSMA/CA SIMULATION RESULTS ---")
for key, value in stats.items():
    print(key.capitalize(), ":", value)

c.close()