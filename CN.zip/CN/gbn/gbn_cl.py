"""TCP Go-Back-N sender using newline-framed messages."""

import json
import socket


SERVER = ("127.0.0.1", 5034)


def main():
    count = int(input("Number of Frames: "))
    window = int(input("Window Size: "))
    frames = list(map(int, input("Frames: ").split()))
    lost_frame = int(input("Frame to Lose (-1 for none): "))

    if (count <= 0 or window <= 0 or len(frames) != count
            or len(set(frames)) != count
            or (lost_frame != -1 and lost_frame not in frames)):
        raise SystemExit("Invalid frame count, window size, sequence, or loss choice")

    with socket.create_connection(SERVER) as client:
        stream = client.makefile("rwb")
        stream.write((json.dumps({
            "frames": frames,
            "window": window,
            "lost_frame": lost_frame,
        }) + "\n").encode())
        stream.flush()

        base = 0
        retransmissions = 0
        print("\nStarting Go-Back-N Transmission...\n")
        while base < count:
            end = min(base + window, count)
            print("Sending Frames:", frames[base:end])
            next_base = base
            timed_out = False
            for index in range(base, end):
                stream.write((str(frames[index]) + "\n").encode())
                stream.flush()
                response = stream.readline().decode(errors="replace").strip()
                if response.startswith("ACK "):
                    print(response)
                    next_base = index + 1
                else:
                    print(response or "Connection closed")
                    timed_out = True
                    break

            base = next_base
            if timed_out:
                retransmissions += 1
                print("Retransmitting from:", frames[base])

        stream.write(b"END\n")
        stream.flush()
        print("\nTransmission Completed Successfully")
        print("Go-Back-N retransmission rounds:", retransmissions)


if __name__ == "__main__":
    main()
