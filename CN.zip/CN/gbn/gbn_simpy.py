
import simpy
import random
import time
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing, payload_size

def receiver(env, channel, ack_channel, lost_frame, stats, timing, frames):
    expected_index = 0
    loss_occurred = False

    while True:
        seq, send_time = yield channel.get()

        yield env.timeout(timing.propagation_delay)

        # Simulate loss of the selected frame once
        if seq == lost_frame and not loss_occurred:
            print(f"Time {env.now:.2f}: Frame {seq} lost")
            loss_occurred = True
            stats["lost"] += 1
            continue

        # Go-Back-N receiver accepts only the expected frame
        if expected_index < len(frames) and seq == frames[expected_index]:
            print(f"Time {env.now:.2f}: Frame {seq} received")

            expected_index += 1
            stats["received"] += 1

            yield env.timeout(timing.processing_delay)
            yield env.timeout(timing.one_way_delay(len("ACK")))
            yield ack_channel.put(seq)

            stats["acks"] += 1
            print(f"Time {env.now:.2f}: ACK {seq} sent")

        else:
            print(
                f"Time {env.now:.2f}: Frame {seq} discarded; "
                f"expected Frame {frames[expected_index] if expected_index < len(frames) else 'none'}"
            )


def sender(env, channel, ack_channel, n, window, frames, stats, timing):
    base = 0

    # Store first transmission time for each frame
    first_sent = {}

    while base < n:
        end = min(base + window, n)

        # Send the current window
        for i in range(base, end):
            if i not in first_sent:
                first_sent[i] = env.now

            print(f"Time {env.now:.2f}: Sending Frame {frames[i]}")

            yield channel.put((frames[i], env.now))

            stats["transmissions"] += 1

            if stats["transmissions"] > n:
                stats["retransmissions"] += 1

            yield env.timeout(timing.transmission_time(
                payload_size(frames[i], timing.packet_size_bytes)
            ))

        # Wait for ACKs until timeout
        timeout = (
            2 * timing.round_trip_delay(timing.packet_size_bytes)
            + 2 * timing.processing_delay
        )
        yield env.timeout(timeout)

        # Collect ACKs received during the waiting period
        acknowledged = set()

        while ack_channel.items:
            ack = yield ack_channel.get()
            acknowledged.add(ack)

        # Advance base through consecutively acknowledged frames
        while base < end and frames[base] in acknowledged:
            stats["total_delay"] += env.now - first_sent[base]
            base += 1

        # If the window is incomplete, Go-Back-N retransmits
        # from the first unacknowledged frame
        if base < end:
            print(
                f"Time {env.now:.2f}: TIMEOUT! "
                f"Retransmitting from Frame {frames[base]}"
            )

    print(f"Time {env.now:.2f}: Transmission completed")


# Main program
n = int(input("Number of frames: "))
window = int(input("Window size: "))

frames = list(map(int, input("Enter frame sequence: ").split()))
lost_frame = int(input("Frame to lose (-1 for none): "))

if (
    n <= 0
    or window <= 0
    or len(frames) != n
    or len(set(frames)) != n
    or (lost_frame != -1 and lost_frame not in frames)
):
    print("Invalid input")

else:
    stats = {
        "transmissions": 0,
        "retransmissions": 0,
        "received": 0,
        "lost": 0,
        "acks": 0,
        "total_delay": 0
    }

    env = simpy.Environment()
    timing = get_link_timing()

    # Communication channels
    channel = simpy.Store(env)
    ack_channel = simpy.Store(env)

    # Start receiver
    env.process(
        receiver(env, channel, ack_channel, lost_frame, stats, timing, frames)
    )

    # Start sender
    sender_process = env.process(
        sender(env, channel, ack_channel, n, window, frames, stats, timing)
    )

    start = time.perf_counter()

    # Run until sender completes
    env.run(until=sender_process)

    execution_time = time.perf_counter() - start

    # Performance report
    print("\n====== PERFORMANCE REPORT ======")
    print("Total frames:", n)
    print("Successful frames:", stats["received"])
    print("ACKs received:", stats["acks"])
    print("Frames lost:", stats["lost"])
    print("Total transmissions:", stats["transmissions"])
    print("Retransmissions:", stats["retransmissions"])

    if n > 0:
        print(
            f"Frame delivery ratio: "
            f"{stats['received'] / n * 100:.2f}%"
        )

    if stats["received"] > 0:
        print(
            f"Average delay: "
            f"{stats['total_delay'] / stats['received']:.2f} seconds"
        )

    if env.now > 0:
        print(
            f"Throughput: "
            f"{stats['received'] / env.now:.2f} frames/second"
        )

    print(f"Simulation time: {env.now:.2f} seconds")
    print(f"Actual execution time: {execution_time:.6f} seconds")
