"""TCP Go-Back-N receiver using newline-framed messages."""

import json
import socket
import threading


def client_handler(client, address):
    with client:
        stream = client.makefile("rwb")
        try:
            config_line = stream.readline()
            if not config_line:
                return
            config = json.loads(config_line)
            frames = [int(frame) for frame in config["frames"]]
            lost_frame = int(config["lost_frame"])
        except (ValueError, KeyError, TypeError, json.JSONDecodeError):
            stream.write(b"ERROR invalid configuration\n")
            stream.flush()
            return

        print(f"Client {address} connected; frames={frames}")
        expected_index = 0
        simulated_loss_done = False
        while True:
            line = stream.readline()
            if not line:
                break
            text = line.decode(errors="replace").strip()
            if text == "END":
                break
            try:
                frame = int(text)
            except ValueError:
                stream.write(b"ERROR invalid frame\n")
                stream.flush()
                continue

            if frame == lost_frame and not simulated_loss_done:
                simulated_loss_done = True
                response = f"TIMEOUT {frame}"
                print(f"Frame {frame} lost; expecting retransmission")
            elif expected_index < len(frames) and frame == frames[expected_index]:
                expected_index += 1
                response = f"ACK {frame}"
                print(f"Received Frame {frame}; sent ACK")
            else:
                response = f"DISCARD {frame}"
                print(f"Discarded Frame {frame}")

            stream.write((response + "\n").encode())
            stream.flush()


def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("0.0.0.0", 5034))
        server.listen(5)
        print("GBN Server Started; waiting for clients...")
        while True:
            client, address = server.accept()
            threading.Thread(
                target=client_handler, args=(client, address), daemon=True
            ).start()


if __name__ == "__main__":
    main()
