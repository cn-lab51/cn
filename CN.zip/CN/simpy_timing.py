"""Shared configurable link timing for the CN SimPy demonstrations.

Transmission time is computed as payload bits divided by link bit rate.
The command-line parameters are shared by all simulations that import this
module; unknown arguments are left for a simulation's own parser.
"""

import argparse
from dataclasses import dataclass
from typing import Optional, Sequence


@dataclass(frozen=True)
class LinkTiming:
    bandwidth_mbps: float
    propagation_delay_ms: float
    processing_delay_ms: float
    packet_size_bytes: int
    packet_arrival_rate_pps: float = 20.0
    simulation_time_s: float = 10.0

    @property
    def bandwidth_bps(self) -> float:
        return self.bandwidth_mbps * 1_000_000

    @property
    def propagation_delay(self) -> float:
        return self.propagation_delay_ms / 1000

    @property
    def processing_delay(self) -> float:
        return self.processing_delay_ms / 1000

    def transmission_time(self, payload_bytes: Optional[int] = None) -> float:
        size_bytes = self.packet_size_bytes if payload_bytes is None else payload_bytes
        if size_bytes < 0:
            raise ValueError("payload size cannot be negative")
        return size_bytes * 8 / self.bandwidth_bps

    def transmission_time_bits(self, payload_bits: int) -> float:
        if payload_bits < 0:
            raise ValueError("payload size cannot be negative")
        return payload_bits / self.bandwidth_bps

    def one_way_delay(self, payload_bytes: Optional[int] = None) -> float:
        return self.transmission_time(payload_bytes) + self.propagation_delay

    def one_way_delay_bits(self, payload_bits: int) -> float:
        return self.transmission_time_bits(payload_bits) + self.propagation_delay

    def round_trip_delay(self, payload_bytes: Optional[int] = None) -> float:
        return 2 * self.one_way_delay(payload_bytes)


def get_link_timing(argv: Optional[Sequence[str]] = None) -> LinkTiming:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--bandwidth-mbps", type=float, default=10.0)
    parser.add_argument("--propagation-delay-ms", type=float, default=5.0)
    parser.add_argument("--processing-delay-ms", type=float, default=1.0)
    parser.add_argument("--packet-size-bytes", type=int, default=1024)
    parser.add_argument("--packet-arrival-rate-pps", type=float, default=20.0)
    parser.add_argument("--simulation-time-s", type=float, default=10.0)
    args, _ = parser.parse_known_args(argv)
    if args.bandwidth_mbps <= 0:
        parser.error("--bandwidth-mbps must be greater than zero")
    if args.propagation_delay_ms < 0 or args.processing_delay_ms < 0:
        parser.error("delay values cannot be negative")
    if args.packet_size_bytes < 0:
        parser.error("--packet-size-bytes cannot be negative")
    if args.packet_arrival_rate_pps <= 0 or args.simulation_time_s <= 0:
        parser.error("packet arrival rate and simulation time must be positive")
    return LinkTiming(
        bandwidth_mbps=args.bandwidth_mbps,
        propagation_delay_ms=args.propagation_delay_ms,
        processing_delay_ms=args.processing_delay_ms,
        packet_size_bytes=args.packet_size_bytes,
        packet_arrival_rate_pps=args.packet_arrival_rate_pps,
        simulation_time_s=args.simulation_time_s,
    )


def payload_size(value: object, fallback: int) -> int:
    """Return a byte count for common text/binary payloads."""
    if isinstance(value, str):
        return len(value.encode("utf-8"))
    if isinstance(value, (bytes, bytearray, memoryview)):
        return len(value)
    if isinstance(value, (dict, list, tuple, int, float)):
        return len(str(value).encode("utf-8"))
    return fallback
