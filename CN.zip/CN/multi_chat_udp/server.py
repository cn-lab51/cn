import socket
import threading

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind(("127.0.0.1", 5000))

clients = {}

print("Server waiting for connections...")

def broadcast(message, sender):
    for address in clients:
        if address != sender:
            server.sendto(message.encode(), address)


def handle_client(client_address, data):
    if client_address not in clients:
        username = data.decode()
        clients[client_address] = username
        print(username, "connected")
        return

    username = clients[client_address]
    message = data.decode()

    if message.lower() == "exit":
        del clients[client_address]
        print(username, "disconnected")
        return

    message = username + ": " + message
    print(message)
    broadcast(message, client_address)


def receive():
    while True:
        data, client_address = server.recvfrom(1024)
        handle_client(client_address, data)

receive()