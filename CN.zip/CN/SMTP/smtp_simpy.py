from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

def send_mail(env, stats, n, timing):
    start = env.now
    print(f"{env.now:.1f}s Client {n}: connect, EHLO, MAIL FROM, RCPT TO")
    request = "EHLO MAIL FROM RCPT TO"
    yield env.timeout(timing.one_way_delay(len(request)))
    yield env.timeout(timing.processing_delay)
    print(f"{env.now:.1f}s Client {n}: DATA (sending email)")
    message = "Subject: demo email"
    yield env.timeout(timing.one_way_delay(len(message)))
    yield env.timeout(timing.processing_delay)
    yield env.timeout(timing.one_way_delay(len("250 accepted")))
    print(f"{env.now:.1f}s Client {n}: server returns 250 accepted")
    stats["ok"] += 1; stats["delay"] += env.now-start

env = simpy.Environment(); timing = get_link_timing(); stats = {"ok": 0, "delay": 0.0}
for n in range(1, 4): env.process(send_mail(env, stats, n, timing))
env.run()
print("Emails accepted:", stats["ok"], "Average completion time:", round(stats["delay"]/stats["ok"], 2), "s")
