import socket

HOST, PORT = "127.0.0.1", 2525
with socket.create_connection((HOST, PORT)) as s:
    f = s.makefile("rwb")
    print(f.readline().decode().strip())
    for cmd in ["EHLO localhost", "MAIL FROM:<student@example.com>", "RCPT TO:<teacher@example.com>"]:
        f.write((cmd + "\r\n").encode()); f.flush()
        print(">", cmd, "\n", f.readline().decode().strip())
    f.write(b"DATA\r\n"); f.flush()
    print(">", "DATA", "\n", f.readline().decode().strip())
    for line in ["Subject: CN Lab Demo", "", "Hello from the SMTP socket demo.", "."]:
        f.write((line + "\r\n").encode()); f.flush()
    print(f.readline().decode().strip())
    f.write(b"QUIT\r\n"); f.flush()
    print(f.readline().decode().strip())
