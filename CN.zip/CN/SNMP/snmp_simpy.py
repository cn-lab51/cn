from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing
objects = {"sysName": "LabRouter", "sysLocation": "Computer Lab", "sysUpTime": "3600 seconds"}

def manager(env, stats, name, timing):
    start = env.now
    print(f"{env.now:.1f}s SNMP manager: GET {name}")
    yield env.timeout(timing.one_way_delay(len(name)))
    yield env.timeout(timing.processing_delay)
    if name in objects:
        print(f"{env.now:.1f}s Agent: RESPONSE {name}={objects[name]}")
        stats["ok"] += 1
    else:
        print(f"{env.now:.1f}s Agent: ERROR unknown object {name}")
        stats["fail"] += 1
    yield env.timeout(timing.one_way_delay(len(str(objects.get(name, "error")))))
    stats["delay"] += env.now-start

env = simpy.Environment(); timing = get_link_timing(); stats = {"ok": 0, "fail": 0, "delay": 0.0}
for name in ["sysName", "sysLocation", "sysUpTime", "unknownObject"]:
    env.process(manager(env, stats, name, timing))
env.run()
total = stats["ok"] + stats["fail"]
print("GET requests:", total, "Successful:", stats["ok"], "Failed:", stats["fail"],
      "Average response time:", round(stats["delay"]/total, 2), "s")
