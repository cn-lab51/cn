import socket

HOST, PORT = "127.0.0.1", 1161
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    s.settimeout(3)
    for name in ["sysName", "sysLocation", "sysUpTime", "unknownObject"]:
        print("GET:", name)
        s.sendto(name.encode(), (HOST, PORT))
        try:
            data, _ = s.recvfrom(1024)
            print("Response:", data.decode())
        except socket.timeout:
            print("No response (timeout)")
    s.sendto(b"QUIT", (HOST, PORT))
    print("Response:", s.recvfrom(1024)[0].decode())
