from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

def transfer(env, stats, n, timing):
    start = env.now
    size_kb = timing.packet_size_bytes / 1024
    print(f"{env.now:.1f}s Client {n}: connect and request file ({size_kb} KB)")
    yield env.timeout(timing.one_way_delay(len("GET file")))
    yield env.timeout(timing.processing_delay)
    yield env.timeout(timing.one_way_delay(size_kb * 1024))
    yield env.timeout(timing.one_way_delay(len("transfer complete")))
    print(f"{env.now:.1f}s Client {n}: transfer complete")
    stats["ok"] += 1; stats["bytes_kb"] += size_kb; stats["time"] += env.now-start

env = simpy.Environment(); timing = get_link_timing(); stats = {"ok": 0, "bytes_kb": 0, "time": 0.0}
for n in range(1, 4): env.process(transfer(env, stats, n, timing))
env.run()
print("Completed transfers:", stats["ok"], "Total data:", stats["bytes_kb"], "KB",
      "Average transfer time:", round(stats["time"]/stats["ok"], 2), "s")
