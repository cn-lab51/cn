import socket

HOST, PORT = "127.0.0.1", 1110
with socket.create_connection((HOST, PORT)) as s:
    f = s.makefile("rwb")
    print(f.readline().decode().strip())
    for command in ["USER student", "PASS demo", "STAT", "LIST", "RETR 1", "QUIT"]:
        f.write((command + "\r\n").encode()); f.flush()
        print(">", command)
        first = f.readline().decode(errors="replace").strip()
        print(first)
        if command.split()[0] in ("LIST", "RETR") and first.startswith("+OK"):
            while True:
                line = f.readline().decode(errors="replace").rstrip()
                if line == ".":
                    break
                print(line)
        if command == "QUIT":
            break
