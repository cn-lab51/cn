from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

def client(env, stats, timing):
    start = env.now
    print(f"{env.now:.1f}s POP3 client: connect and authenticate")
    yield env.timeout(timing.one_way_delay(len("USER PASS")))
    yield env.timeout(timing.processing_delay)
    print(f"{env.now:.1f}s POP3 client: STAT/LIST request")
    yield env.timeout(timing.one_way_delay(len("STAT LIST")))
    yield env.timeout(timing.processing_delay)
    print(f"{env.now:.1f}s POP3 client: RETR message")
    yield env.timeout(timing.one_way_delay(timing.packet_size_bytes))
    yield env.timeout(timing.processing_delay)
    yield env.timeout(timing.one_way_delay(len("RETR response")))
    stats["ok"] += 1
    stats["delay"] += env.now - start
    print(f"{env.now:.1f}s POP3 client: message received, QUIT")

env = simpy.Environment(); timing = get_link_timing(); stats = {"ok": 0, "delay": 0.0}
for _ in range(3): env.process(client(env, stats, timing))
env.run()
print("Requests:", stats["ok"], "Average response time:", round(stats["delay"]/stats["ok"], 2), "s")
