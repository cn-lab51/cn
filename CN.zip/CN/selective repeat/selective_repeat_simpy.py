# Selective Repeat ARQ - SimPy Simulation
# Install first: pip install simpy
# Run: python selective_repeat_simpy.py
# This is a discrete-event simulation; it does not use real sockets.

import random
from pathlib import Path
import sys
import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing, payload_size

def sender(env, receiver, stats, timing, total_frames, window_size,
           loss_probability):
    base = 0
    next_seq = 0
    acked = [False] * total_frames
    timer = {}
    transmissions = 0
    timeout = 2 * timing.round_trip_delay(timing.packet_size_bytes) + 2 * timing.processing_delay
    print(f"{env.now:5.1f}s | Sender starts: frames={total_frames}, window={window_size}")

    while not all(acked):
        # Send new frames that fit into the current sender window.
        while next_seq < total_frames and next_seq < base + window_size:
            transmissions += 1
            stats["transmissions"] += 1
            timer[next_seq] = env.now
            print(f"{env.now:5.1f}s | SEND frame {next_seq}")
            env.process(channel_to_receiver(
                env, receiver, next_seq, stats, timing, loss_probability
            ))
            next_seq += 1

        # Wait for an ACK event or a short tick to check individual timers.
        yield env.timeout(timeout)

        # Selectively retransmit only expired, unacknowledged frames.
        for seq in range(base, min(base + window_size, total_frames)):
            if not acked[seq] and seq in timer and env.now - timer[seq] >= timeout:
                transmissions += 1
                stats["transmissions"] += 1
                stats["retransmissions"] += 1
                timer[seq] = env.now
                print(f"{env.now:5.1f}s | TIMEOUT -> retransmit frame {seq}")
                env.process(channel_to_receiver(
                    env, receiver, seq, stats, timing, loss_probability
                ))

        # ACKs are stored by receiver in stats; sender processes them here.
        for seq in list(stats["pending_acks"]):
            if 0 <= seq < total_frames:
                acked[seq] = True
                timer.pop(seq, None)
                stats["pending_acks"].remove(seq)
                print(f"{env.now:5.1f}s | ACK {seq} accepted by sender")

        while base < total_frames and acked[base]:
            base += 1

    stats["completion_time"] = env.now
    print(f"{env.now:5.1f}s | All frames acknowledged.")

def channel_to_receiver(env, receiver, seq, stats, timing,
                        loss_probability):
    yield env.timeout(timing.one_way_delay(timing.packet_size_bytes))
    if random.random() < loss_probability:
        stats["lost_frames"] += 1
        print(f"{env.now:5.1f}s | CHANNEL LOST frame {seq}")
        return
    yield env.process(receiver.receive(seq, stats, timing))

class Receiver:
    def __init__(self, env):
        self.env = env
        self.expected = 0
        self.buffer = {}
        self.delivered = []

    def receive(self, seq, stats, timing):
        print(f"{self.env.now:5.1f}s | Receiver got frame {seq}")
        # Every received frame is individually acknowledged, including duplicates.
        yield self.env.timeout(timing.processing_delay)
        yield self.env.timeout(timing.one_way_delay(len("ACK")))
        stats["pending_acks"].append(seq)

        if seq not in self.delivered and seq not in self.buffer:
            self.buffer[seq] = True

        while self.expected in self.buffer:
            self.buffer.pop(self.expected)
            self.delivered.append(self.expected)
            print(f"{self.env.now:5.1f}s | Receiver delivers frame {self.expected}")
            self.expected += 1

def main():
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frames", type=int, default=12)
    parser.add_argument("--window-size", type=int, default=4)
    parser.add_argument("--loss-probability", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()
    if args.frames < 1 or args.window_size < 1:
        parser.error("frames and window size must be positive")
    if not 0 <= args.loss_probability < 1:
        parser.error("loss probability must be in [0, 1)")

    random.seed(args.seed)
    timing = get_link_timing()
    env = simpy.Environment()
    receiver = Receiver(env)
    stats = {
        "transmissions": 0,
        "retransmissions": 0,
        "lost_frames": 0,
        "pending_acks": [],
        "completion_time": 0.0,
    }
    env.process(sender(
        env, receiver, stats, timing, args.frames, args.window_size,
        args.loss_probability
    ))
    env.run()

    delivered = len(receiver.delivered)
    sent = stats["transmissions"]
    print("\n========== PERFORMANCE SUMMARY ==========")
    print(f"Frames delivered in order : {delivered}/{args.frames}")
    print(f"Total transmissions       : {sent}")
    print(f"Retransmissions           : {stats['retransmissions']}")
    print(f"Frames lost in channel    : {stats['lost_frames']}")
    print(f"Completion time           : {stats['completion_time']:.1f} simulated seconds")
    print(f"Delivery ratio            : {delivered / args.frames * 100:.1f}%")
    print(f"Transmission efficiency   : {args.frames / sent * 100:.1f}%" if sent else "Transmission efficiency: N/A")

if __name__ == "__main__":
    main()
