# Selective Repeat ARQ - UDP Client
# Run the server first, then: python selective_repeat_client.py
# Sends frames using a sliding window. Only unacknowledged frames are retransmitted
# when their individual timeout expires.

import socket
import time

SERVER = ("127.0.0.1", 5005)
TOTAL_FRAMES = 10
WINDOW_SIZE = 4
TIMEOUT = 1.0
RETRY_LIMIT = 10

def main():
    acked = [False] * TOTAL_FRAMES
    sent_at = [None] * TOTAL_FRAMES
    retries = [0] * TOTAL_FRAMES
    next_to_send = 0
    start = time.perf_counter()

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        client.settimeout(0.1)
        print("Selective Repeat sender started.")
        print(f"Frames={TOTAL_FRAMES}, window={WINDOW_SIZE}, timeout={TIMEOUT}s\n")

        while not all(acked):
            # Fill the current sliding window.
            while next_to_send < TOTAL_FRAMES and next_to_send < first_unacked(acked) + WINDOW_SIZE:
                send_frame(client, next_to_send, sent_at, retries, acked)
                next_to_send += 1

            try:
                packet, _ = client.recvfrom(1024)
                message = packet.decode(errors="replace").strip().split("|")
                if len(message) == 2 and message[0] == "ACK":
                    seq = int(message[1])
                    if 0 <= seq < TOTAL_FRAMES and not acked[seq]:
                        acked[seq] = True
                        print(f"ACK {seq} received.")
            except socket.timeout:
                pass
            except (ValueError, OSError) as exc:
                print(f"Receive warning: {exc}")

            # Selectively retransmit only frames whose own timer has expired.
            now = time.perf_counter()
            for seq in range(TOTAL_FRAMES):
                if sent_at[seq] is not None and not acked[seq] and now - sent_at[seq] >= TIMEOUT:
                    if retries[seq] >= RETRY_LIMIT:
                        print(f"Frame {seq} exceeded retry limit; stopping.")
                        return
                    retries[seq] += 1
                    send_frame(client, seq, sent_at, retries, acked, retransmission=True)

        elapsed = time.perf_counter() - start
        total_retransmissions = sum(retries)
        print("\nTransmission complete.")
        print(f"Frames acknowledged: {sum(acked)}/{TOTAL_FRAMES}")
        print(f"Retransmissions: {total_retransmissions}")
        print(f"Elapsed time: {elapsed:.3f} seconds")

def first_unacked(acked):
    for i, is_acked in enumerate(acked):
        if not is_acked:
            return i
    return len(acked)

def send_frame(sock, seq, sent_at, retries, acked, retransmission=False):
    payload = f"Message_{seq}"
    sock.sendto(f"DATA|{seq}|{payload}".encode(), SERVER)
    sent_at[seq] = time.perf_counter()
    if retransmission:
        print(f"Timeout: retransmitted frame {seq} (attempt {retries[seq]}).")
    else:
        print(f"Sent frame {seq}.")

if __name__ == "__main__":
    main()
