import socket

s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('localhost', 1227))
s.listen(1)

print("Waiting for client...")
c, addr = s.accept()
print("Client connected")

stuffed = c.recv(1024).decode()
print("Stuffed data:", stuffed)

# Bit Destuffing
data = ""
count = 0
i = 0

while i < len(stuffed):
    bit = stuffed[i]
    data += bit

    if bit == '1':
        count += 1
    else:
        count = 0

    if count == 5:
        i += 1
        count = 0

    i += 1

print("Destuffed data:", data)
c.send(data.encode())

c.close()
s.close()
