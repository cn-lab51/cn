from pathlib import Path
import sys

import simpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing

def sender(env, channel, data, timing):
    stuffed = ""
    count = 0

    for bit in data:
        stuffed += bit

        if bit == '1':
            count += 1
        else:
            count = 0

        if count == 5:
            stuffed += '0'
            count = 0

    print("Sender: Original data =", data)
    print("Sender: Stuffed data  =", stuffed)

    yield env.timeout(timing.one_way_delay_bits(len(stuffed)))
    yield channel.put(stuffed)


def receiver(env, channel, timing):
    stuffed = yield channel.get()
    yield env.timeout(timing.processing_delay)

    destuffed = ""
    count = 0
    i = 0

    while i < len(stuffed):
        bit = stuffed[i]
        destuffed += bit

        if bit == '1':
            count += 1
        else:
            count = 0

        if count == 5:
            i += 1  # Skip the stuffed zero
            count = 0

        i += 1

    print("Receiver: Received stuffed data =", stuffed)
    print("Receiver: Destuffed data        =", destuffed)


env = simpy.Environment()
timing = get_link_timing()
channel = simpy.Store(env)

data = input("Enter data bits: ")

env.process(sender(env, channel, data, timing))
env.process(receiver(env, channel, timing))

env.run()
