import socket
import struct

def checksum(data):
    total = 0

    for byte in data:
        total += byte

    total = (total & 255) + (total >> 8)
    total = (total & 255) + (total >> 8)

    return (~total) & 255


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(("127.0.0.1", 5000))

message = input("Enter transaction message: ")

data = message.encode()

check = checksum(data)

print("Checksum:", check)

error = input("Introduce error? (y/n): ")

if error == "y":
    data = bytearray(data)

    # Change one bit
    data[0] = data[0] ^ 1

    data = bytes(data)

client.sendall(struct.pack("!I", len(data)) + data + bytes([check]))

result = client.recv(1024).decode()

print("Server:", result)

client.close()
