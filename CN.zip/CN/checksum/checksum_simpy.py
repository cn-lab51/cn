
import simpy
import random
import time
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simpy_timing import get_link_timing, payload_size

# Simulation parameters
NUM_PACKETS = 20
ERROR_PROBABILITY = 0.2


# Checksum calculation
def checksum(data):
    total = sum(data)

    total = (total & 255) + (total >> 8)
    total = (total & 255) + (total >> 8)

    return (~total) & 255


# Shared performance statistics
stats = {
    "sent": 0,
    "received": 0,
    "valid": 0,
    "corrupted": 0,
    "total_delay": 0
}


# Simulated server process
def server(env, packet, original_checksum, send_time, timing):
    # Simulate network transmission
    yield env.timeout(timing.one_way_delay(payload_size(packet, timing.packet_size_bytes)))

    # Simulate server processing time
    yield env.timeout(timing.processing_delay)

    stats["received"] += 1

    received_time = env.now
    delay = received_time - send_time
    stats["total_delay"] += delay

    # Validate received packet
    received_checksum = checksum(packet)

    if received_checksum == original_checksum:
        stats["valid"] += 1
        result = "Valid - No Error Detected"
    else:
        stats["corrupted"] += 1
        result = "Corrupted - Error Detected"

    print(
        f"Time: {env.now:.2f}s | "
        f"Packet: {stats['received']} | "
        f"Delay: {delay:.2f}s | "
        f"Result: {result}"
    )


# Simulated client process
def client(env):
    for i in range(NUM_PACKETS):
        message = f"Packet-{i + 1}"
        data = message.encode()

        # Calculate checksum before transmission
        original_checksum = checksum(data)

        # Simulate transmission errors
        if random.random() < ERROR_PROBABILITY:
            data = bytearray(data)
            data[0] ^= 1
            data = bytes(data)

        stats["sent"] += 1
        send_time = env.now

        print(
            f"Time: {env.now:.2f}s | "
            f"Client sending Packet {i + 1}"
        )

        # Start server processing concurrently
        env.process(
            server(env, data, original_checksum, send_time, timing)
        )

        # Generate packets at regular intervals
        yield env.timeout(timing.one_way_delay(timing.packet_size_bytes))


# Run the simulation
random.seed(42)
timing = get_link_timing()

env = simpy.Environment()
start = time.perf_counter()

env.process(client(env))
env.run()

execution_time = time.perf_counter() - start


# Performance evaluation
sent = stats["sent"]
received = stats["received"]
valid = stats["valid"]
corrupted = stats["corrupted"]

print("\n========== PERFORMANCE REPORT ==========")
print("Total packets sent:", sent)
print("Total packets received:", received)
print("Valid packets:", valid)
print("Corrupted packets:", corrupted)

if sent > 0:
    delivery_ratio = received / sent * 100
    print(f"Packet delivery ratio: {delivery_ratio:.2f}%")

if received > 0:
    average_delay = stats["total_delay"] / received
    print(f"Average packet delay: {average_delay:.2f} seconds")

    throughput = received / env.now
    print(f"Throughput: {throughput:.2f} packets/second")

print(f"Simulation time: {env.now:.2f} seconds")
print(f"Actual execution time: {execution_time:.6f} seconds")
